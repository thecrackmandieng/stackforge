import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import authRoutes from './routes/auth.routes.js';
import categorieRoutes from './routes/categorie.routes.js';
import utilisateurRoutes from './routes/utilisateur.routes.js';

const app = express();

app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({ status: true, service: 'Test React API' });
});

app.use('/api/auth', authRoutes);
app.use('/api/categorie', categorieRoutes);
app.use('/api/utilisateur', utilisateurRoutes);

app.use((error, req, res, next) => {
  console.error(error);
  res.status(500).json({
    message: error.message || 'Erreur serveur'
  });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  console.log(`Test React backend running on http://localhost:${port}`);
});
